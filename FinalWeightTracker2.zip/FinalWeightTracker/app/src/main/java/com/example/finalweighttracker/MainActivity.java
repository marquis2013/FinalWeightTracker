package com.example.finalweighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //Initialize Variable
    EditText etText;
    Button btAdd;
    Button btView;
    ListView listView;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign Variable
        etText = findViewById(R.id.et_text);
        btAdd = findViewById(R.id.bt_add);
        btView = findViewById(R.id.bt_view);

        //Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(MainActivity.this);


        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Get text from EditText
                String newEntry = etText.getText().toString();
                if (etText.length() != 0){
                    AddData(newEntry);
                    etText.setText("");
                }else{
                    toastMessage("You need to add today's weight!");
                }

            }
        });

        btView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });

    }
        public void AddData(String newEntry){
            boolean insertData = databaseHelper.addData(newEntry);

            if (insertData) {
                toastMessage("Data Successfully Inserted!");
            }
            else {
                toastMessage("Something went wrong");
            }
        }

        private void toastMessage(String message){
            Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
        }
}